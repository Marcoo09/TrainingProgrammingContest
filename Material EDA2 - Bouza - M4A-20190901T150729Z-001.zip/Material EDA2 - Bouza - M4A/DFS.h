Puntero<Lista<Puntero<Lista<int>>>> cantComponentesConexas(){
	Array<bool> vis = Array<bool>(tope, false);
	Puntero<Lista<Puntero<Lista<V>>>> lista = new ListaImp<Puntero<Lista<V>>>();
	int cont = 0, proxPos = 0;
	do
	{
		Puntero<Lista<V>> nueva = new ListaImp<V>();
		cont++;
		DFS(proxPos, vis, nueva);
		lista -> Insertar(nueva);
		proxPos = devolverNoVisitado(vis);
	}while(proxPos != -1);
	return lista;
}

int devolverNoVisitado(Array<bool> &vis)
{
	for(int i = 0; i<tope; i++)
	{
		if(!vis[i])
		{
			return i;
		}
	}
	return -1;
}

void DFS(int ver, Array<bool> &vis, Puntero<Lista<V>>& lista)
{
	lista -> Insertar(vertices[ver]);
	vis[ver] = true;
	for(int i = 0; i < tope; i++)
	{
		if(!vis[i] && matAdy[ver][i] != INF)
		{
			DFS(i, vis, lista);
		}
	}
}