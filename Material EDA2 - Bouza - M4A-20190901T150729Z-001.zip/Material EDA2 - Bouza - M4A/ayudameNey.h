Iterador<int> ayudameNey(Array<int> estaciones)
{
	int largo = estaciones.ObtenerLargo();
	Array<Tupla<int, int>> saltos = Array<Tupla<int, int>>(largo);
	saltos[largo-1] = Tupla<int, int>(0, -1);
	for(int i = largo-2; i>=0; i--)
	{
		if(i + estaciones[i] >= largo-1)
		{
			saltos[i] = Tupla<int, int>(1, largo-1);
		}
		else
		{
			int min = estaciones[i+1], posMin = i+1;
			for(j = i+2; j< i+estaciones[i]; j++)
			{
				if(min > saltos[j])
				{
					min = saltos[j];
					posMin = j;
				}
			}
			saltos[i] = Tupla<int, int>(min+1, posMin);
		}
	}
	
	Array<int> ret = Array<int>(saltos[0].ObtenerDato1()+1);
	ret[0] = 0;
	int prox = saltos[0].ObtenerDato2();
	int cont = 1;
	while(prox != largo-1)
	{
		ret[cont++] = prox;
		prox = saltos[prox].ObtenerDato2();
	}
	ret[ret.ObtenerLargo()-1] = prox;
	return ret.ObtenerIterador();
	
}