Tupla<int,Iterador<V>> dijkstra(V origen, V destino, const Grafo<V, int>& g){
	
	int tope = g->CantidadElementos();
	
	Array<int> dist = Array<int>(tope);
	Array<int> ant = Array<int>(tope);
	Array<bool> vis = Array<bool>(tope);
	
	Array<V> vertices = g->ObtenerVertices();
	
	for(int i = 0; i < tope; dist[i] = INF, ant[i] = -1, vis[i] = false, i++);
	
	dijkstraInterno(posOrigen, dist, ant, vis, vertices);
	
	Array<int> temp = Array<int>(tope);
	int posAnt = posDestino;
	int cont = 0;
	do{
		temp[cont++] = posAnt;
		posAnt = ant[posAnt];
	}while(posAnt != -1);
	
	Array<V> arrAlReves = Array<V>(cont);
	for(int i=0; i<cont; i++)
	{
		arrAlReves[i] = temp[cont-1-i];
	}
	
	return Tupla<int, Iterador<V>>(dist[posDestino], arrAlReves.ObtenerIterador());
}

int pos(Array<V> &vertices, V dato)
{
	for(int i = 0; i<tope; i++)
	{
		if(vertices[i] == dato)
		{
			return i;
		}
	}
	return -1;
}


void dijkstraInterno(int posOrigen, Array<int>& dist, Array<int>& ant, Array<bool>& vis, const Grafo<V, int>& g, Array<V> vertices){
	// Inicializo el origen
	dist[posOrigen] = 0;
	vis[posOrigen] = true;
	// Seteo distancias del origen a sus adyacentes
	foreach(auto v, g->Adyacentes(posOrigen))
	{
		int i = pos(v);
		dist[i] = g->ObtenerArista(vertices[posOrigen],v);
		ant[i] = posOrigen;
	}
	
	
	// Comienzo proceso iterativo
	for(int k = 1; k < tope; k++)
	{
		// Encuentro candidato
		int min = INF, posMin = -1;
		for(int i = 0; i < tope; i++){
			if(!vis[i] && dist[i] < min)
			{
				min = dist[i];
				posMin = i;
			}
		}
		// Si no hay adyacentes no visitados, me voy
		if(posMin == -1)
			return;
		
		vis[posMin] = true;
		
		// Actualizo distancias del candidato (posMin)
		foreach(auto v2, g->Adyacentes(posMin))
		{
			int i = pos(v2);
			if(!vis[i] && puedoPasar(v2, iteradorNoPasar))
			{
				int distCandidata = dist[posMin] + g->ObtenerArista(vertices[posMin],v2);
				if(distCandidata < dist[i])
				{
					dist[i] = distCandidata;
					ant[i] = posMin;
				}
			}
		}
	}
}

bool puedoPasar(V dato, Iterador<V> iteradorNoPasar){
	foreach(auto elem, iteradorNoPasar)
	{
		if(elem == dato)
		{
			return false;
		}
	}
	return true;
}