template<class V, class A>
class Grafo abstract{
	public:
		virtual void AgregarVertice(const V&) abstract;
		//Pre: existen ambos vértices
		virtual void AgregarArista(const V&, const V&, const A&) abstract;
		//Pre: existe el vertice
		virtual void BorrarVertice(const V&) abstract;
		//Pre: existen ambos vértices
		virtual void BorrarArista(const V&, const V&) abstract;
		
		virtual Iterador<V> ObtenerVertices() abstract;
		//Pre: existe el vértice
		virtual Iterador<V> Adyacentes(const V&) abstract;
		
		virtual bool EsVacio() abstract;
		//Pre: existen ambos vértices
		virtual bool ExisteArista(const V&, const V&) abstract;
		virtual bool ExisteVertice(const V&) abstract;
		//Pre: existe arista entre ambos
		virtual const A& ObtenerArista(const V&, const V&) abstract;
		
		virtual int CantidadVertices() abstract;	
};








foreach (auto elem, lista)
{
	
}