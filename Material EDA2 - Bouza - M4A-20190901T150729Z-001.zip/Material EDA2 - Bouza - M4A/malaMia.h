Array<Tupla<int, int>> malaMiaDisculpame(Matriz<char> casa, Tupla<int,int> ventana,
Tupla<int,int> puertaDormitorio, int ruidoMaximo)
{
	Array<Tupla<int,int>> solActual = Array<Tupla<int,int>>(casa.ObtenerLargo() * casa.ObtenerAncho());
	solActual[0] = ventana;
	Array<Tupla<int,int>> solOptima = Array<Tupla<int,int>>(casa.ObtenerLargo() * casa.ObtenerAncho());
	Array.Copiar(solActual, solOptima);
	int posOptima = 1, ruidoOptimo = INF;
	Matriz<bool> vis = Matriz<bool>(casa.ObtenerLargo(), casa.ObtenerAncho());
	
	int[] coordX {1,-1,0,0};
	int[] coordY {0,0,1,-1};
	
	malaMiaBack(casa, ventana, puertaDormitorio, ruidoMaximo, solActual, 1, 0, solOptima, posOptima, ruidoOptimo, vis, coordX, coordY);
	
	Array<Tupla<int, int>> ret = Array<Tupla<int, int>>(posOptima);
	Array.Copiar(solOptima, 0, posOptima, ret);
	return ret;
	
}

void malaMiaBack(Matriz<char>& casa, Tupla<int,int> actual,
Tupla<int,int> puertaDormitorio, int ruidoMaximo, 
Array<Tupla<int,int>> solActual, int posActual, int ruidoActual, 
Array<Tupla<int,int>>& solOptima, int& posOptima, int& ruidoOptimo,
Matriz<bool>& vis, int * coordX, int * coordY)
{
	if(actual == puertaDormitorio)
	{
		ruidoOptimo = ruidoActual;
		posOptima = posActual;
		Array.Copiar(solActual,0,posActual, solOptima);
	}else{
		for(int k = 0; k < 4; k++){
			int posX = actual.ObtenerDato1() + coordX[k];
			int posY = actual.ObtenerDato2() + coordY[k];
			if(posX >= 0 && posY >= 0 && posX < casa.ObtenerLargo() && posY < casa.ObtenerAncho()
				&& !vis[posX][posY] && casa[posX][posY] != 'P')
			{
				int ruido = obtenerRuido(casa[posX][posY]);
				ruidoActual += ruido;
				if(ruidoActual < ruidoOptimo && ruidoActual < ruidoMaximo){
					Tupla<int, int> nueva = Tupla<int, int>(posX, posY);
					vis[posX][posY] = true;
					solActual[posActual] = nueva;
					malaMiaBack(casa, actual, puertaDormitorio, ruidoMaximo, solActual, posActual+1, ruidoActual, solOptima, posOptima, ruidoOptimo, vis, coordX, coordY);
				}
			}
		}
	}
}