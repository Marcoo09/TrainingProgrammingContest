Iterador<Tupla<Cadena,int>> mochila(Iterador<Tupla<Cadena, int, double>> elementos, int cantElementos, int peso)
{
	Array<Tupla<Cadena,int>> ret = Array<Tupla<Cadena,int>>(cantElementos);
	int contador = 0;
	
	Puntero<ColaPrioridad<int, Tupla<Cadena, int, double>>> cola = new ColaPrioridadHeap<int, Tupla<Cadena, int, double>>(Comparador<int>::Default, const CadenaFuncionHash& fh, cantElementos);
	foreach(auto elem, elementos)
	{
		cola.insertar(elem.ObtenerDato3()/elem.ObtenerDato2(), elem);
	}
	
	while(!cola->esVacia() && peso != 0)
	{
		Tupla<Cadena, int, double> elem = cola->borrarMin();
		int cantVecesEntra = peso/elem.ObtenerDato2();
		if(cantVecesEntra > 0)
		{
			ret[contador++] = Tupla<Cadena, int>(elem.ObtenerDato1(), cantVecesEntra);
			peso -= elem.ObtenerDato2() * cantVecesEntra;
		}
	}
	
	return new ArrayIteracion<Tupla<Cadena, int>>(ret, contador);
}