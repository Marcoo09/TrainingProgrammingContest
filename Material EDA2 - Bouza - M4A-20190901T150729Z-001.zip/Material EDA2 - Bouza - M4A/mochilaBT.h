Iterador<Tupla<float, float>> mochila(Array<float> peso, Array<float> valor, float pesoMochila)
{
	Array<float> solA = Array<float>(peso.ObtenerLargo(), 0);
	Array<float> solOpt = Array.CopiarArray(solA);
	float valorO = -1.0;
	nat cantO = 0;
	mochilaBT(pesoMochila, 0, 0, 0, valorO, cantO, solA, solOpt);
	Array<Tupla<float, float>> ret = Array<Tupla<float, float>>(cantO);
	int posRet = 0;
	for(int i = 0; i < solOpt.ObtenerLargo(); i++)
	{
		if(solOpt[i] == 1)
		{
			ret[posRet++] = Tupla<float, float>(peso[i], valor[i]);
		}
	}
	return ret.ObtenerIterador();
}

void mochilaBT(float pesoA, float valorA, nat cantA, int elemento, float &valorO, nat &cantO, Array<float> solA, Array<float> & solOpt){
	if(elemento == solA.ObtenerLargo()){
		if(valorA > valorO){
			solOpt = Array.CopiarArray(solA);
			valorO = valorA;
			cantO = cantA;
		}
	}
	else{
		mochilaBT(pesoA, valorA, cantA, elemento+1, valorO, cantO, Array.CopiarArray(solA),  solOpt);
		if(pesoA >= peso[elemento]){
			pesoA -= peso[elemento];
			valorA+= valor[elemento];
			solA[elemento]++;
			mochilaBT(pesoA, valorA, cantA+1, elemento+1, valorO, cantO, Array.CopiarArray(solA),  solOpt);
		}
	}	
}	