Iterador<Tupla<int, int>> mochila(Array<int> peso, Array<int> valor, int pesoMochila)
{
	int largo = peso.ObtenerLargo();
	int ancho = pesoMochila + 1;
	Matriz<int> mat = Matriz<int>(peso.ObtenerLargo(), pesoMochila + 1);
	
	for(int i = 0; i < largo; mat[i++][0]=0);
	for(int j = 0; j < ancho; mat[0][j] = (j<peso[0] ? 0 : valor[0]), j++);
	
	for(int i = 1; i < largo; i++)
	{
		for(int j = 1; j < ancho; j++)
		{
			mat[i][j] = (j < peso[i]
				? mat[i-1][j]
				: max(mat[i-1][j], mat[i-1][j-peso[i]]+valor[i]));
		}
	}
	
	Array<Tupla<int,int>> ret = Array<Tupla<int,int>>(largo);
	int cont = 0;
	int jAux = pesoMochila;
	int iAux = largo-1;
	while(iAux != 0)
	{
		if(mat[iAux][jAux] == mat[iAux-1][jAux])
			iAux--;
		else
		{
			ret[cont++] = Tupla<int,int>(peso[iAux],valor[jAux]);
			jAux-=valor[iAux];
			iAux--;
		}
	}
	if(mat[0][jAux] != 0)
	{
		ret[cont] = Tupla<int,int>(peso[0],valor[jAux]);
	}

	return new ArrayIteracion<Tupla<int,int>>(ret,cont);
}