Iterador<Tupla<int, int>> monedas(Iterador<int> denominaciones, 
	int monto, int cantDenominaciones)
{
	Array<Tupla<int,int>> retorno = Array <Tupla<int,int>>(cantDenominaciones);
	int contador=0;
	foreach (auto monedaActual, denominaciones)
	{
		int cantMonedasxd = monto/monedaActual;
		if(cantMonedasxd>0){
			retorno[contador++] = Tupla<int,int>(monedaActual,cantMonedasxd);
			monto -= cantMonedasxd*monedaActual;
		}
		
		if(monto == 0)
			break;
		
	}
	return new ArrayIteracion<Tupla<int,int>>(retorno,contador);
}