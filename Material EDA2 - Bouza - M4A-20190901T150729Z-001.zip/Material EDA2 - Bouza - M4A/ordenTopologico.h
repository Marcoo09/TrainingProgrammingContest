Array<int> ordenTopologico()
{
	Array<int> ret = Array<int>(tope, -1);
	Array<int> gradosEnt = gradosEntrantes();
	
	for(int i=0; i<tope; i++)
	{	
		int proxVert = verticeConGradoEntCero(gradosEnt);
		if(proxVert == -1)
			return new Array<int>(0);
		ret[proxVert] = i;
		
		for(int j=0; j<tope; j++)
		{
			if(matAdy[proxVert][j] != INF)
			{
				gradosEnt[j]--;
			}
		}
	}
}

int verticeConGradoEntCero(Array<int> gradosEnt)
{
	int ret = -1;
	
	for(int i=0; i<tope; i++)
	{	
		if(gradosEnt[i] == 0)
		{
			return i;
		}
	}
	return ret;
}

Array<int> gradosEntrantes()
{
	Array<int> ret = Array<int>(tope, 0);
	for(int i=0; i<tope; i++)
	{		
		for(int j=0; j<tope; j++)
		{
			if(matAdy[i][j] != INF)
			{
				ret[j]++;
			}
		}
	}
	return ret;
}